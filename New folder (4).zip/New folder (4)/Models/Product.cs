﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ECommerceMVCApp.Models
{
    [Table("ProductDetails")]
    public class Product
    {
        public int productId { get; set; }
        [Required(ErrorMessage ="Name cannot be left blank")]
        //[MaxLength(16,ErrorMessage = "Name must not exceed 16 characters")]
        //[MinLength(8, ErrorMessage = "Name must be atleast 8 characters")]
        public string name { get; set; }
        [Required]
        public decimal price { get; set; }
        [Required]
        public string description { get; set; }
    }
}