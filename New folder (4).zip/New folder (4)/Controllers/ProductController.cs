﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ECommerceMVCApp.Models;

namespace ECommerceMVCApp.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        [HttpGet]
        public ActionResult CreateProduct()
        {
            return View();
        }

        //Add product the database
        [HttpPost]
        public ActionResult CreateProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                ProductContext productContext = new ProductContext();
                productContext.products.Add(product);
                productContext.SaveChanges();
                return RedirectToAction("ProductList", "Product");
            }
            return View();
        }

        public ActionResult ProductList()
        {
            ProductContext productContext = new ProductContext();
            List<Product> products = productContext.products.ToList();
            return View(products);
        }
        public ActionResult EditProduct(int id)
        {
            ProductContext productContext = new ProductContext();
            return View(productContext.products.ToList().Find(p => p.productId == id));
        }

        [HttpPost]
        public ActionResult EditProduct(Product product)
        {
            ProductContext productContext = new ProductContext();
            Product producttoBeupdated = productContext.products.ToList().Find(p => p.productId == product.productId);
            producttoBeupdated.name = product.name;
            producttoBeupdated.price = product.price;
            producttoBeupdated.description = product.description;
            productContext.SaveChanges();
            return RedirectToAction("ProductList", "Product");
        }

      
        public ActionResult DeleteProduct(int id)
        {
            ProductContext productContext = new ProductContext();
            Product productToDelete = productContext.products.ToList().Find(p => p.productId ==id);
            productContext.products.Remove(productToDelete);
            productContext.SaveChanges();
            return RedirectToAction("ProductList", "Product");
        }
        }
}